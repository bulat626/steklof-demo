(() => {
  'use strict';
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const mobile = matchMedia('(max-width: 600px)');
  const menu = $('.menu-toggle'), nav = $('#main-nav');
  function closeMenu(restoreFocus = false) {
    if (!menu || !nav) return;
    menu.setAttribute('aria-expanded', 'false');
    menu.setAttribute('aria-label', 'Открыть меню');
    nav.classList.remove('open');
    if (restoreFocus) menu.focus();
  }
  menu?.addEventListener('click', () => {
    const open = menu.getAttribute('aria-expanded') !== 'true';
    menu.setAttribute('aria-expanded', String(open));
    menu.setAttribute('aria-label', open ? 'Закрыть меню' : 'Открыть меню');
    nav.classList.toggle('open', open);
  });
  nav?.addEventListener('click', e => { if (e.target.closest('a')) closeMenu(); });
  document.addEventListener('click', e => { if (!e.target.closest('header')) closeMenu(); });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && menu?.getAttribute('aria-expanded') === 'true') closeMenu(true);
  });
  mobile.addEventListener('change', () => closeMenu());
  const quickBar = $('.mobile-contact-bar'), requestSection = $('#request');
  if (quickBar && requestSection && 'IntersectionObserver' in window) {
    new IntersectionObserver(entries => {
      quickBar.hidden = entries[0].isIntersecting;
    }, { rootMargin: '-80px 0px -90px 0px', threshold: 0 }).observe(requestSection);
  }
  $$('.article-toc').forEach(toc => { toc.open = !mobile.matches; });
  $$('.swatch').forEach(button => button.addEventListener('click', () => {
    const box = button.closest('.color-picker'), picture = $('.color-image', box);
    picture.removeAttribute('srcset');
    picture.src = button.dataset.colorImage;
    picture.alt = button.dataset.colorLabel;
    $('#color-name', box).textContent = button.dataset.colorLabel;
    $$('.swatch', box).forEach(b => b.setAttribute('aria-pressed', String(b === button)));
  }));

  const dialog = $('#lightbox');
  let gallery = [], current = 0, previousOverflow = '', touch = null;
  function showPhoto(index) {
    current = (index + gallery.length) % gallery.length;
    const a = gallery[current];
    const caption = a.dataset.caption || $('img', a)?.alt || 'Фотография проекта Стеклоф';
    $('img', dialog).src = a.href;
    $('img', dialog).alt = caption;
    $('#lightbox-caption').textContent = `${current + 1} / ${gallery.length} · ${caption}`;
    $('.lightbox-prev', dialog).hidden = gallery.length < 2;
    $('.lightbox-next', dialog).hidden = gallery.length < 2;
  }
  $$('[data-lightbox]').forEach(a => a.addEventListener('click', e => {
    if (e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return;
    e.preventDefault();
    const group = a.closest('.gallery-batch, .prose');
    gallery = group ? $$('[data-lightbox]', group) : [a];
    showPhoto(gallery.indexOf(a));
    previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    dialog.showModal();
  }));
  $('.dialog-close', dialog)?.addEventListener('click', () => dialog.close());
  $('.lightbox-prev', dialog)?.addEventListener('click', () => showPhoto(current - 1));
  $('.lightbox-next', dialog)?.addEventListener('click', () => showPhoto(current + 1));
  dialog?.addEventListener('close', () => { document.body.style.overflow = previousOverflow; });
  dialog?.addEventListener('click', e => {
    if (e.target !== dialog) return;
    const r = dialog.getBoundingClientRect();
    if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) dialog.close();
  });
  dialog?.addEventListener('keydown', e => {
    if (e.key === 'ArrowRight') { e.preventDefault(); showPhoto(current + 1); }
    if (e.key === 'ArrowLeft') { e.preventDefault(); showPhoto(current - 1); }
  });
  $('.lightbox-stage', dialog)?.addEventListener('touchstart', e => { touch = e.touches.length === 1 ? [e.touches[0].clientX, e.touches[0].clientY] : null; }, { passive: true });
  $('.lightbox-stage', dialog)?.addEventListener('touchend', e => {
    if (!touch || !e.changedTouches.length || gallery.length < 2) return;
    const dx = e.changedTouches[0].clientX - touch[0], dy = e.changedTouches[0].clientY - touch[1];
    if (Math.abs(dx) > 60 && Math.abs(dy) < 60) showPhoto(current + (dx < 0 ? 1 : -1));
    touch = null;
  }, { passive: true });

  $$('.load-more').forEach(button => {
    const grid = button.previousElementSibling;
    function update() {
      const remaining = $$('[hidden]', grid).length;
      button.hidden = remaining === 0;
      button.textContent = `Показать ещё ${Math.min(24, remaining)} фото · осталось ${remaining} ↓`;
    }
    button.addEventListener('click', () => { $$('[hidden]', grid).slice(0, 24).forEach(el => { el.hidden = false; }); update(); });
    update();
  });
  $$('[data-filter]').forEach(button => button.addEventListener('click', () => {
    $$('[data-filter]').forEach(b => { b.classList.toggle('active', b === button); b.setAttribute('aria-pressed', String(b === button)); });
    $$('.filter-section').forEach(section => { section.hidden = button.dataset.filter !== 'all' && section.dataset.category !== button.dataset.filter; });
  }));

  const form = $('#project-form');
  if (form) {
    const service = $('#service'), result = $('#message-result'), send = $('#send-link');
    const requested = new URLSearchParams(location.search).get('service') || document.body.dataset.defaultService;
    if ([...service.options].some(option => option.value === requested)) service.value = requested;
    function prepare() {
      const fields = new FormData(form);
      const note = String(fields.get('message') || '').trim();
      const lines = ['Здравствуйте! Хочу обсудить проект со Стеклоф.', `Услуга: ${fields.get('service')}`, `Имя: ${String(fields.get('name')).trim()}`, `Объект: ${String(fields.get('city')).trim()}`];
      if (note) lines.push(note);
      $('#message-preview').textContent = lines.join('\n');
      send.href = 'https://wa.me/79178771400?text=' + encodeURIComponent(lines.join('\n'));
    }
    form.addEventListener('input', () => {
      $$('input[required]', form).forEach(input => input.setCustomValidity(''));
      result.hidden = true;
      send.removeAttribute('href');
    });
    form.addEventListener('change', () => { result.hidden = true; send.removeAttribute('href'); });
    form.addEventListener('submit', e => {
      e.preventDefault();
      $$('input[required]', form).forEach(input => input.setCustomValidity(input.value.trim() ? '' : 'Пожалуйста, заполните поле.'));
      if (!form.reportValidity()) return;
      prepare(); result.hidden = false;
      send.focus({ preventScroll: true });
      result.scrollIntoView({ block: 'nearest', behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth' });
    });
  }
})();
